import os

os.system("shutdown -i")