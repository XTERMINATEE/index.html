import colorama
import requests
import socket
ipinfo = input("Input IP address> ")
ip_res = requests.get(f"http://ip-api.com/json/{ipinfo}").json()
try:
        hostname = socket.gethostbyaddr(ipinfo)[0]
except socket.herror:
        hostname = "N/A"

ipout = f"""
{colorama.Fore.YELLOW}IP Information{colorama.Fore.RESET}

{colorama.Fore.LIGHTBLUE_EX}Country:{colorama.Fore.RESET}  {ip_res.get("country")}
{colorama.Fore.LIGHTBLUE_EX}Region:{colorama.Fore.RESET}   {ip_res.get("regionName")}
{colorama.Fore.LIGHTBLUE_EX}City:{colorama.Fore.RESET}     {ip_res.get("city")}
{colorama.Fore.LIGHTBLUE_EX}Zip:{colorama.Fore.RESET}      {ip_res.get("zip")}
{colorama.Fore.LIGHTBLUE_EX}ISP:{colorama.Fore.RESET}      {ip_res.get("isp")}
{colorama.Fore.LIGHTBLUE_EX}IP:{colorama.Fore.RESET}       {ip_res.get("query")}
{colorama.Fore.LIGHTBLUE_EX}Hostname:{colorama.Fore.RESET} {hostname}
"""
print(ipout)