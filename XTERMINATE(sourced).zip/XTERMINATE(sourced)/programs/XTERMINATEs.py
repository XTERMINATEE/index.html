import subprocess
import sys
import requests            # Required to install
import shutil
import os
from colorama import Fore  # Required to install


########################################
# This is a menu screen
# Change it to whatever it suits you
menu = f"""
\033[2;37m███████████████████\033[0m ╭─────────────────────────────╮
\033[2;37m█                 █\033[0m │    Welcome to {Fore.LIGHTBLUE_EX}XTERMINATE\033[0m    │
\033[2;37m█\033[0m {Fore.BLUE}██   ██ ██      \033[2;37m█\033[0m │                             │
\033[2;37m█\033[0m  {Fore.LIGHTBLUE_EX}██ ██    ██    \033[2;37m█\033[0m │    Type {Fore.YELLOW}HELP\033[0m for list of    │
\033[2;37m█\033[0m   {Fore.CYAN}███       ██  \033[2;37m█\033[0m │    available commands       │
\033[2;37m█\033[0m  {Fore.LIGHTBLUE_EX}██ ██    ██    \033[2;37m█\033[0m │                             │
\033[2;37m█\033[0m {Fore.BLUE}██   ██ ██      \033[2;37m█\033[0m │        Version 1.0.0        │
\033[2;37m█                 █\033[0m ╰─────────────────────────────╯
\033[2;37m███████████████████\033[0m  {Fore.RED}█████████{Fore.GREEN} # Open Sourced \033[0m 
  \033[2;37m████████████o██\033[0m    {Fore.RED}█ █ooo█ █{Fore.GREEN} # Downloadable commands \033[0m 
\033[2;37m███████████████████────\033[0m{Fore.RED}█████{Fore.GREEN}   # User Friendly \033[0m 
│"""       
#
#######################################
print(menu)
while True:
 x = input(f"╰┤{Fore.LIGHTBLUE_EX}X{Fore.RESET}├───────┤ ").upper() # Input bar

################# LIST OF AVAILABLE commandS #####################

 if x == "list".upper():
    list = requests.get("https://xterminatee.github.io/XTERMINATE/").text           # Fetches list of available commands
    rm_words = {"form", "action", "button", "command"}                              # Banned words
    list_spl = list.split()                                                         # Words spliced out
    filtered = [ w for w in list_spl if not any(b in w.lower() for b in rm_words) ] # Words filtered out


    cmd = os.path.dirname(os.path.abspath(__file__))   # First path
    path1 = os.path.join(cmd, "programs")              # Combine with folder

    fs = []                                            # List of commands installed

    for i in os.listdir(path1):                        # For every file that exists in path
     if i.endswith(".exe"):                             # If a file ends with .exe it strips it
        fs.append(os.path.splitext(i)[0])

    
    
    ###########################
    # This is a list command screen
    # Feel free to change it
    # but DONT remove the {filtered}

    online = f"""
    [ LIST OF AVAILABLE COMMAND TO DOWNLOAD ]

    {Fore.YELLOW}{filtered}{Fore.RESET}

    [ LIST OF DOWNLOADED COMMANDS]

    {Fore.YELLOW}{fs}{Fore.RESET}
    """
    print(online) # OUTPUT

################# INSTALL A command #####################

 if x == "install".upper():
  print(" ")
  item = input("Insert command Name> ").upper()                  # Input command name
  print(f"Downloading {item}.exe....")
  url = f'https://xterminatee.github.io/XTERMINATE/{item}.exe'    # Get command from site
  r = requests.get(url, allow_redirects=True)                    # Download


  sec = os.path.dirname(os.path.abspath(__file__))               # First path
  path1 = os.path.join(sec, "programs")                          # Combine with folder

  file_path = os.path.join(path1, f"{item}.exe")                  # EXE file path

  with open(file_path, 'wb') as f:                               # Create file
    f.write(r.content)                                           # Write in binary

  print(f"{Fore.GREEN}Download success{Fore.RESET}")

 
################# HELP COMMAND #####################
 # This is a help screen
 # Feel free to change it
 if x == "HELP".upper(): 
    helpme = f"""
╭───── {Fore.GREEN}HELP{Fore.RESET} ───────────────────────────────────────────────╮
│ {Fore.LIGHTBLUE_EX}EXIT      {Fore.YELLOW}- Exits out of this program{Fore.RESET}                    │
│ {Fore.LIGHTBLUE_EX}HELP      {Fore.YELLOW}- Shows list of available commands{Fore.RESET}             │
│ {Fore.LIGHTBLUE_EX}INSTALL   {Fore.YELLOW}- Installs command of your choice{Fore.RESET}              │
│ {Fore.LIGHTBLUE_EX}LIST      {Fore.YELLOW}- Lists all the command available to download{Fore.RESET}  │
│             {Fore.YELLOW}and lists all commands you already installed{Fore.RESET} │
│ {Fore.LIGHTBLUE_EX}UNINSTALL {Fore.YELLOW}- Uninstalls command of your choice{Fore.RESET}            │
├──────────────────────────────────────────────────────────╯"""
    print(helpme)

################# EXIT COMMAND #####################
 if x == "EXIT".upper(): 
    exit() # exit 

################# UNINSTALL COMMAND #####################
 if x == "UNINSTALL".upper():
    uninstall = input("Insert command to uninstall> ").upper()
    if os.name == "posix":
     os.remove(f"{os.path.dirname(os.path.abspath(__file__))}/programs/{uninstall}.exe") # removes a command you inputed
     print(f"{Fore.GREEN}Uninstallment success")
    else:
       os.remove(f"{os.path.dirname(os.path.abspath(__file__))}\\programs\\{uninstall}.exe") # removes a command you inputed
       print(" ")
       print(f"{Fore.GREEN}Uninstalment success")
################# EXECUTION COMMAND #####################

 else:
      sec = os.path.dirname(os.path.abspath(__file__)) # Find the current path
      path = os.path.join(sec, "programs", f"{x}.exe") # Join in

      if not os.path.isfile(path): # Debugging use
       pass                        
      else:
       subprocess.run([sys.executable, path], check=True) # Run command from program file