import os

ping = input("Input IP address> ")

while True:
    os.system(f"ping -n 65527 -l 3 {ping}")