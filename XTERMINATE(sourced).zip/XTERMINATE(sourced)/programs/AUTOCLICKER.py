import mouse
import time

cps = int(input("Input how much clicks per second> "))
delay = int(input("Input delay to start> "))

time.sleep(delay)
while True:
 time.sleep(1 / cps)
 mouse.click("left")
