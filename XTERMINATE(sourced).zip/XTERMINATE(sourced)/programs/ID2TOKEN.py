import base64

id = input("Input Discord User ID> ")
encode = base64.b64encode(id.encode("utf-8"))
out = str(encode, "utf-8")

print(out)