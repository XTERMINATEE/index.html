import socket
import colorama

ip = input("Input IP address> ")
port = input("Input Port number> ")

soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
soc.settimeout(2)
result = soc.connect_ex((ip, int(port)))
if result == 0:
    print(" ")
    print(f"{colorama.Fore.GREEN}[+] Port {port} has been found{colorama.Fore.RESET}")
    print(" ")
else:
    print(" ")
    print(f"{colorama.Fore.RED}[-] Port {port} has NOT been found{colorama.Fore.RESET}")
    print(" ")
    soc.close()