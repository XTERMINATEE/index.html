import requests

URL = input("Input URL> ")
FILE_TO_SAVE_AS = "myvideo.mp4"


resp = requests.get(URL)

with open(FILE_TO_SAVE_AS, "wb") as f:
    f.write(resp.content) 
