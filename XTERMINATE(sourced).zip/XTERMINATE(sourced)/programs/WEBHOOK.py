import requests

web = input("Input webhook url> ")
msg = input("Input message> ")
data = {
    "content":msg
}
while True:
    getweb = requests.get(web)
    res = requests.post(web, json=data)