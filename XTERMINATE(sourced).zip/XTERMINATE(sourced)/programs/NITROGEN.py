import requests
import random
import time
we = input("Input Discord webhook> ")

chars = 'abcdefghijklnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'
while True:
    time.sleep(0.1)
    pa =''
    for i in range(16):
        pa += random.choice(chars)
        msg = "https://discord.gift/" + pa
    data = {
    "content":msg
    }
    getweb = requests.get(we)
    res = requests.post(we, json=data)